package com.reagente.manager.manager.repository;

import com.reagente.manager.manager.entity.Fornecedor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FornecedorRepository extends JpaRepository<Fornecedor, Integer> {

}
