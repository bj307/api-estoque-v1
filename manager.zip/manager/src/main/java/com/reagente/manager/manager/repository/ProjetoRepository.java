package com.reagente.manager.manager.repository;

import com.reagente.manager.manager.entity.Projeto;
import org.springframework.data.jpa.repository.JpaRepository;



public interface ProjetoRepository extends JpaRepository<Projeto, Integer> {

}
