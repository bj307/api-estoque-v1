package com.reagente.manager.manager.repository;

import com.reagente.manager.manager.entity.Laboratorio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LaboratorioRepository extends JpaRepository<Laboratorio, Integer> {
}
